
function login() {
  const user = document.getElementById('username').value;
  const pass = document.getElementById('password').value;
  if ((user === 'tabrez' && pass === 'Tabrez@12') || (user === 'GNC' && pass === 'Gnc@13')) {
    document.getElementById('loginBox').classList.add('hidden');
    document.getElementById('formBox').classList.remove('hidden');
  } else {
    document.getElementById('login-error').innerText = "Invalid Username or Password!";
  }
}

document.getElementById("repairForm").addEventListener("submit", function(e){
  e.preventDefault();
  const data = {
    name: document.getElementById("name").value,
    mobile: document.getElementById("mobile").value,
    device: document.getElementById("device").value,
    issue: document.getElementById("issue").value,
    date: document.getElementById("date").value,
    cost: document.getElementById("cost").value
  };
  displayReceipt(data);
});

function displayReceipt(data) {
  const content = `
    <p><strong>Customer Name:</strong> ${data.name}</p>
    <p><strong>Mobile:</strong> ${data.mobile}</p>
    <p><strong>Device:</strong> ${data.device}</p>
    <p><strong>Issue:</strong> ${data.issue}</p>
    <p><strong>Date:</strong> ${data.date}</p>
    <p><strong>Estimated Cost:</strong> ₹${data.cost}</p>
    <br/>
    <p>Customer Signature: _______________________</p>
    <p>Technician Signature: ______________________</p>
  `;
  document.getElementById("receiptContent").innerHTML = content;
  document.getElementById("receipt").classList.remove("hidden");
}
